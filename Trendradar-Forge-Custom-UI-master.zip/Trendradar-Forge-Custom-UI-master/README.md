# Forge Trend Radar App

This project contains a Forge custom UI app written in React that displays The Trend Radar App in a Confluence macro.

See [developer.atlassian.com/platform/forge/](https://developer.atlassian.com/platform/forge) for documentation and tutorials explaining Forge.

## Requirements

See [Set up Forge](https://developer.atlassian.com/platform/forge/set-up-forge/) for instructions to get set up.

## Quick start

### Register the app

-   Register the app by running:

```
forge register
```

### Frontend

-   Change into the frontend directory by running:

```
cd ./static/trendradar
```

-   Install your frontend dependencies by running:

```
npm install
```

-   Build your frontend by running:

```
npm run build
```

### Deployment

For this section, ensure you have navigated back to the root of the repository.

-   Install the forge dependencies by running:

```
npm install
```

-   Build and deploy your app by running:

```
forge deploy
```

-   Install your app in an Atlassian site by running:

```
forge install
```

## Support

See [Get help](https://developer.atlassian.com/platform/forge/get-help/) for how to get help and provide feedback.
