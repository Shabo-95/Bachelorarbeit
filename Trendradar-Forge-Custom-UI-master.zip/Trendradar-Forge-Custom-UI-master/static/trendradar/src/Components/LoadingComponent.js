import React from "react";
import { ProgressSpinner } from "primereact/progressspinner";

// Diese Komponente wird angezeigt, während die Daten des Trendradars geladen werden
export const LoadingComponent = () => {
    return (
        <div>
            <h1>Daten werden geladen</h1>
            <ProgressSpinner
                style={{ width: "50px", height: "50px" }}
                strokeWidth="3"
            />
        </div>
    );
};
