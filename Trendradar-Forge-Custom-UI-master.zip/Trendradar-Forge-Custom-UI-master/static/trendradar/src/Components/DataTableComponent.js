import React, { useState, useEffect } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";

export const DataTableComponent = ({
    passedRadarDataFromParent,
    passFilteredRadarDataToParent,
}) => {
    const [radarData, setRadarData] = useState([]);
    const [filteredData, setFilteredData] = useState(undefined);
    const [ValueToPass, setValueToPass] = useState([]);
    let quadrantsArr = [];
    let ringsArr = [];
    let radarDataCopy;

    useEffect(() => {
        // Der Array-Index von Quadranten und Ringen wird durch ihre Beschriftung ersetzt
        setRadarData(replaceIndexWithTheirLabels());
    }, []);

    useEffect(() => {
        if (filteredData) {
            radarDataCopy = passedRadarDataFromParent;
            setValueToPass({
                ...radarDataCopy,
                entries: replaceLabelsWithTheirIndex(),
            });
        }
    }, [filteredData]);

    useEffect(() => {
        // Der Zweck dieser if-Anweisung ist es, zu verhindern, dass das leere Array "ValueToPass"
        // beim ersten Rendern der Komponente an dem Parent-Component übergeben wird.
        if (ValueToPass.length != 0) {
            passFilteredRadarDataToParent(ValueToPass);
        }
    }, [ValueToPass]);

    const replaceIndexWithTheirLabels = () => {
        return passedRadarDataFromParent.entries.map((entry) => {
            return {
                id: entry.id,
                quadrant:
                    passedRadarDataFromParent.quadrants[entry.quadrant].name,
                ring: passedRadarDataFromParent.rings[entry.ring].name,
                label: entry.label,
                active: entry.active,
                moved: entry.moved,
                hidden: false,
            };
        });
    };

    const replaceLabelsWithTheirIndex = () => {
        passedRadarDataFromParent.quadrants.map((quadrant) => {
            quadrantsArr.push(quadrant.name);
        });

        passedRadarDataFromParent.rings.map((ring) => {
            ringsArr.push(ring.name);
        });

        // Die Beschriftung von Quadranten und Ringen wird durch ihren Array-Index ersetzt
        return filteredData.map((entry) => {
            return {
                quadrant: quadrantsArr.indexOf(entry.quadrant),
                ring: ringsArr.indexOf(entry.ring),
                label: entry.label,
                active: entry.active,
                moved: entry.moved,
                hidden: entry.hidden,
            };
        });
    };

    // Diese Funktion wird nach jeder Filterung der Daten in der Tabelle aufgerufen
    const filterRadarData = (filteredData) => {
        let radarDataCopy = radarData;
        // Zunächst werden alle Blips versteckt
        radarDataCopy.map((radarDataEntry, index) => {
            radarDataCopy[index].hidden = true;
        });
        // Danach werden nur noch die gefilterten Blips nach ihrem Index angezeigt
        filteredData.map((filteredDataEntry) => {
            let objIndex = radarDataCopy.findIndex(
                (obj) => obj.id == filteredDataEntry.id
            );
            radarDataCopy[objIndex].hidden = false;
        });
        setFilteredData([...radarDataCopy]);
    };

    return (
        <div className="card">
            <DataTable
                value={radarData}
                showGridlines
                filterDisplay="row"
                responsiveLayout="scroll"
                paginator
                rows={10}
                onValueChange={(filteredData) => {
                    filterRadarData(filteredData);
                }}
                sortField="id"
                sortOrder={1}
                emptyMessage="Es wurden keine Ergebnisse gefunden"
            >
                <Column field="id" header="ID" style={{ width: "5%" }}></Column>
                <Column
                    field="quadrant"
                    header="Quadrant"
                    filter
                    filterPlaceholder="Filter nach Quadranten"
                    style={{ width: "31.66%" }}
                ></Column>
                <Column
                    field="ring"
                    header="Ring"
                    filter
                    filterPlaceholder="Filter nach Ringe"
                    style={{ width: "31.66%" }}
                ></Column>
                <Column
                    field="label"
                    header="Beschriftung"
                    filter
                    filterPlaceholder="Filter nach Label"
                    style={{ width: "31.66%" }}
                ></Column>
            </DataTable>
        </div>
    );
};
