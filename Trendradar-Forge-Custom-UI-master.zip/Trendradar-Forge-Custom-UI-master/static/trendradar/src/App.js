import React, { useEffect, useState } from "react";
import { invoke } from "@forge/bridge";
import { RadarComponent } from "./Components/RadarComponent";
import { Message } from "primereact/message";
import { DataTableComponent } from "./Components/DataTableComponent";
import { LoadingComponent } from "./Components/LoadingComponent";
import * as csv from "csvtojson";
import "./App.css";

function App() {
    const [loading, setLoading] = useState(true);
    const [radarConfigured, setRadarConfigured] = useState(false);
    const [radarData, setRadarData] = useState(undefined);
    const RadarDataObj = {
        svg_id: "radar",
        width: innerWidth >= 1050 ? innerWidth : 1050,
        height: 1000,
        colors: {
            background: "#fff",
            grid: "#bbb",
            inactive: "#ddd",
        },
        title: "",
        quadrants: [
            { color: "#E6C684" },
            { color: "#70B0D4" },
            { color: "#FCB67D" },
            { color: "#D686A4" },
        ],
        rings: [],
        entries: [],
        print_layout: true,
        //zoomed_quadrant: 0,
    };
    let [refresh, doRefresh] = useState(0);

    // Beim Appstart wird die Funktion "getAttachment" aus dem Backend aufgerufen
    useEffect(() => {
        invoke("getAttachment").then((response) => {
            // Falls die Antwort kein leeres Objekt ist
            if (Object.keys(response).length !== 0) {
                setRadarConfigured(true);
                convertCsvToJson(response);
            } else {
                setLoading(false);
                setRadarConfigured(false);
                setRadarData({
                    ...createSampleTemplate(),
                });
            }
        });
    }, []);

    // Diese Funktion wandelt Csv in Json um, und aktualisiert der State "radarData" in der Komponente
    const convertCsvToJson = (response) => {
        csv({
            delimiter: "auto",
        })
            .fromString(response.attachmentValue)
            .then((arrayOfObjects) => {
                setLoading(false);
                setRadarData({
                    ...RadarDataObj,
                    title: createRadarTitle(response),
                    quadrants: createQuadrantsArray(arrayOfObjects),
                    rings: createRingsArray(arrayOfObjects),
                    entries: replaceLabelsWithTheirIndex(arrayOfObjects),
                });
            })
            // Fehlerbehandlung
            .catch((error) => {
                setLoading(false);
                console.log("Error", error);
            });
    };

    // Diese Funktion erstellt ein Muster-Template für das Trendradar,
    // sie wird aufgerufen, falls es noch keine Daten für das Trendradar gibt
    const createSampleTemplate = () => {
        let radarDataObjCopy = RadarDataObj;
        // Damit das Trendradar (die SVG-Graphik) in der Mitte des Bildschirms angezeigt wird
        let entriesNumber = 0;
        for (let i = 0; i < 4; i++) {
            radarDataObjCopy.quadrants[i].name = "Quadrant " + (i + 1);
            radarDataObjCopy.rings[i] = { name: "Ring " + (i + 1) };
            for (let j = 0; j < 4; j++) {
                radarDataObjCopy.entries[entriesNumber++] = {
                    quadrant: i,
                    ring: j,
                    label: "Blib " + entriesNumber,
                    active: "",
                    moved: "0",
                };
            }
        }
        return radarDataObjCopy;
    };

    // Die Beschriftungen der Quadranten aus dem Parameter arrayOfObjects extrahieren
    const getQuadrants = (arrayOfObjects) => {
        let quadrantsSet = new Set();
        arrayOfObjects.map((obj) => {
            quadrantsSet.add(obj.quadrant);
        });
        let quadrantsArr = [...quadrantsSet];
        // Fehlerbehandlung
        if (quadrantsArr.length > 4) {
            // Nur die ersten 4 Elemente werden zurückgegeben
            return quadrantsArr.slice(0, 4);
        }
        return quadrantsArr;
    };

    // Die Beschriftungen der Ringe aus dem Parameter arrayOfObjects extrahieren
    const getRings = (arrayOfObjects) => {
        let ringsSet = new Set();
        arrayOfObjects.map((obj) => {
            ringsSet.add(obj.ring);
        });
        let ringsArr = [...ringsSet];
        // Fehlerbehandlung
        if (ringsArr.length > 4) {
            // Nur die ersten 4 Elemente werden zurückgegeben
            return ringsArr.slice(0, 4);
        }
        return ringsArr;
    };

    const createQuadrantsArray = (arrayOfObjects) => {
        let result = RadarDataObj.quadrants;
        const quadrantsArr = getQuadrants(arrayOfObjects);
        for (let i in RadarDataObj.quadrants) {
            result[i].name = quadrantsArr[i];
        }
        return result;
    };

    const createRingsArray = (arrayOfObjects) => {
        let result = RadarDataObj.rings;
        const ringsArr = getRings(arrayOfObjects);
        // i <= 3 Weil das Trendradar maximal aus 4 Ringe (0, 1, 2, 3) bestehen darf
        for (let i = 0; i <= 3; i++) {
            result[i] = { name: ringsArr[i] };
        }
        return result;
    };

    // Diese Funktion erstellt der Titel des Radars aus dem Name, Version und Modifikationsdatum des Anhangs
    const createRadarTitle = (response) => {
        return (
            response.attachmentName +
            " - Version " +
            response.attachmentVersion +
            " - " +
            response.attachmentDateTimeModified
        );
    };

    // Denn das Zalando-Techradar ist so programmiert, dass es den Index der Quadranten und
    // der Ringe der einzelnen Einträge (entries) anstatt ihre Beschriftung einlesen kann.
    const replaceLabelsWithTheirIndex = (arrayOfObjects) => {
        let arrayOfObjectsCopy = arrayOfObjects;
        const quadrantsArr = [...getQuadrants(arrayOfObjects)];
        const ringsArr = [...getRings(arrayOfObjects)];
        arrayOfObjectsCopy.map((entry) => {
            // Die Beschriftung von Quadranten und Ringen wird durch ihren Array-Index ersetzt
            entry.quadrant = quadrantsArr.indexOf(entry.quadrant);
            entry.ring = ringsArr.indexOf(entry.ring);
        });
        // Entferne alle zusätzliche Quadranten oder Ringe (wenn der Anzahl der Ringe bzw. Quadranten über 4 ist)
        let filteredArrayOfObjects = arrayOfObjectsCopy.filter((obj) => {
            return obj.quadrant != -1 && obj.ring != -1;
        });
        return filteredArrayOfObjects;
    };

    const triggerRerender = () => {
        doRefresh((prev) => prev + 1);
    };

    // Die Daten des Trendradar werden von der Komponente "DataTableComponent" an "App.js" übergeben
    const passFilteredRadarDataToParent = (value) => {
        setRadarData({ ...value, entries: value.entries });
        triggerRerender();
    };

    return (
        <>
            <div className="text-center">{loading && <LoadingComponent />}</div>
            {!radarConfigured && !loading && (
                <div className="text-center">
                    <Message
                        className="w-full"
                        severity="info"
                        text="Um das Trendradar zu bearbeiten, Klicken Sie auf das
                        Stifsymbol &#128393;"
                    />
                </div>
            )}
            <div className="text-center">
                {radarData && radarData.rings.length != 0 && (
                    <div>
                        <h3>{radarData.title}</h3>
                        <RadarComponent
                            RadarData={radarData}
                            refresh={refresh}
                        />
                    </div>
                )}
            </div>
            {radarData && radarData.rings.length != 0 && (
                <DataTableComponent
                    passedRadarDataFromParent={radarData}
                    passFilteredRadarDataToParent={
                        passFilteredRadarDataToParent
                    }
                />
            )}
        </>
    );
}

export default App;
