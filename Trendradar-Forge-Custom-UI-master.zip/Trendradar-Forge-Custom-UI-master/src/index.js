import ForgeUI, {
    MacroConfig,
    useProductContext,
    useState,
    useConfig,
    render,
    Select,
    Option,
} from "@forge/ui";
import Resolver from "@forge/resolver";
import api, { route } from "@forge/api";

// Diese Funktion holt sich die Meta-Daten der Anhänge einer Confluence-Seite anhand ihre ID.
// Der Aufruf wird mithilfe von Confluence-Rest-API stattfinden.
export const getAllPageAttachments = async (contentId) => {
    const response = await api
        .asUser()
        .requestConfluence(
            route`/rest/api/content/${contentId}/child/attachment`,
            {
                headers: {
                    Accept: "application/json",
                },
            }
        );
    if (!response.ok) {
        return {};
    }
    return await response.json();
};

// Diese Funktion holt sich die Meta-Daten aller Versionen eines Seitenanhangs,
// der auf eine Confluence-Seite liegt anhand seine ID.
// Der Aufruf wird mithilfe von Confluence-Rest-API stattfinden.
const getAllAttachmentVersions = async (attachmentId) => {
    const response = await api
        .asUser()
        .requestConfluence(route`/rest/api/content/${attachmentId}/version`, {
            headers: {
                Accept: "application/json",
            },
        });
    if (!response.ok) {
        return {};
    }
    return await response.json();
};

// Diese Funktion holt sich die Meta-Daten eines Seitenanhangs, der auf eine Confluence-Seite liegt
// anhand von drei Parameter: 1) Die ID der Seite, 2) Die ID des Anhangs, 3) Die Versionsnummer.
// Der Aufruf wird mithilfe von Confluence-Rest-API stattfinden.
const getAttachment = async (contentId, attachmentId, attachmentVersion) => {
    let attachmentDateTimeModified;
    // Wenn attachmentVersion ist gleich -1 das heißt entweder wurde die Version des Anhang nicht ausgewählt
    // oder der Nutzer möchte die letzte Version auswählen
    if (attachmentVersion == -1) {
        const allAttachmentVersions = await getAllAttachmentVersions(
            attachmentId
        );
        // Hier werden die Versionsnummer und das Erstellungsdatum aus der Meta-Daten
        // des aktuellsten Anhangs extrahiert
        const latestVersion = allAttachmentVersions.results[0].number;
        attachmentDateTimeModified = allAttachmentVersions.results[0].when;
        attachmentVersion = latestVersion;
    }
    const response = await api
        .asUser()
        .requestConfluence(
            route`/rest/api/content/${contentId}/child/attachment/${attachmentId}/download?version=${attachmentVersion}`,
            {
                headers: {
                    Accept: "application/json",
                },
            }
        );
    if (!response.ok) {
        console.log("!response.ok !!!!!");
        return {};
    }
    // Hier wird ein Objekt erstellt, der folgende Eigenschaften beinhaltet:
    // 1) response: Der Inhalt der CSV-Datei, der in einem String umgewandelt ist
    // 2) attachmentVersion: Die Versionsnummer des ausgewählten Anhangs
    // 3) attachmentDateTimeModified: Das Erstellungs- bzw. Modifikationsdatum des Anhangs
    return {
        response: await response.text(),
        attachmentVersion: attachmentVersion,
        attachmentDateTimeModified: attachmentDateTimeModified,
    };
};

// Diese Funktion wird jedes Mal beim Konfigurieren des Macros aufgerufen
const Config = () => {
    // Hier werden alle Meta-Daten der Anhänge gespeichert
    const [attachments] = useState(
        getAllPageAttachments(useProductContext().contentId)
    );

    // Hier werden alle Meta-Daten der Versionen eines Anhangs gespeichert
    // Zunächst wird überprüft, ob ein Anhang schon ausgewählt ist, wenn ja dann
    // werden alle versionen dieses Anhangs anhand seine ID geholt ansonsten ist der State nicht definiert
    const [attachmentVersions] =
        useConfig() &&
        Object.keys(useConfig()).length !== 0 &&
        useConfig().attachment
            ? useState(
                  getAllAttachmentVersions(
                      JSON.parse(useConfig().attachment).id
                  )
              )
            : useState(undefined);

    return (
        <MacroConfig>
            {/* Mithilfe der folgenden Select-Komponente lassen sich die Anhänge 
            anhand ihrer Titel auswählen */}
            <Select
                placeholder="Name des Trendradars"
                name="attachment"
                label="Anhang auswählen"
            >
                {attachments &&
                    attachments.results.map((attachment) => {
                        {
                            // label beinhaltet der der anzuzeigende Beschriftungstext eines Anhangs
                            // value beinhaltet alle Meta-Daten eines Anhangs in Form von String
                        }
                        return (
                            <Option
                                label={attachment.title}
                                value={JSON.stringify(attachment)}
                            />
                        );
                    })}
            </Select>
            {/* Mithilfe der folgenden Select-Komponente lassen sich die Versionen 
            der ausgewählten Anhangs auswählen */}
            <Select
                placeholder="Version des Trendradars"
                name="attachmentVersion"
                label="Version des Anhangs auswählen"
            >
                {attachmentVersions &&
                    [{ number: -1, when: null }]
                        .concat(attachmentVersions.results)
                        .map((attachmentVersion) => {
                            {
                                // label beinhaltet der der anzuzeigende Version sowie Erstellungs- bzw.
                                // Modifikationsdatum eines Anhangs.
                                // value beinhaltet alle Meta-Daten einer Anhangsversion in Form von String
                            }
                            return (
                                <Option
                                    label={
                                        attachmentVersion.number == -1
                                            ? "Die aktuellste Version verwenden"
                                            : "Version " +
                                              attachmentVersion.number +
                                              " - " +
                                              new Date(
                                                  attachmentVersion.when
                                              ).toLocaleDateString("de")
                                    }
                                    value={JSON.stringify(attachmentVersion)}
                                />
                            );
                        })}
            </Select>
        </MacroConfig>
    );
};

export const config = render(<Config />);

const resolver = new Resolver();

// Mithilfe von Resolver wird die Funktion "getAttachment" definiert
// Resolver-Funktionen können aus dem Frontend aufgerufen werden
resolver.define("getAttachment", async ({ payload, context }) => {
    if (context.extension.config) {
        // Falls der Anhang bereits ausgewählt ist
        if (context.extension.config.attachment) {
            let attachment = JSON.parse(context.extension.config.attachment);
            let attachmentVersion = -1;
            let attachmentValue;

            // Falls die Anhangsversion auch bereits ausgewählt ist und ist nicht gleich -1
            if (
                context.extension.config.attachmentVersion &&
                JSON.parse(context.extension.config.attachmentVersion).number !=
                    -1
            ) {
                attachmentValue = await getAttachment(
                    context.extension.content.id,
                    JSON.parse(context.extension.config.attachment).id,
                    JSON.parse(context.extension.config.attachmentVersion)
                        .number
                );
                attachmentVersion = attachmentValue.attachmentVersion;
                // Falls die Anhangsversion auch bereits ausgewählt ist und ist gleich -1
            } else {
                attachmentValue = await getAttachment(
                    context.extension.content.id,
                    JSON.parse(context.extension.config.attachment).id,
                    attachmentVersion
                );
            }
            // Hier wird ein Objekt namens response aus dem Titel, der Versionsnummer, dem Erstellungs- bzw.
            // Modifikationsdatum und dem Inhalt eines Anhangs erstellt
            const response = {
                attachmentName: attachment.title,
                attachmentVersion: attachmentValue.attachmentVersion,
                attachmentDateTimeModified: new Date(
                    attachmentVersion != -1
                        ? JSON.parse(context.extension.config.attachmentVersion)
                              .when
                        : attachmentValue.attachmentDateTimeModified
                ).toLocaleTimeString("de", {
                    year: "numeric",
                    month: "numeric",
                    day: "numeric",
                    hour: "2-digit",
                    minute: "2-digit",
                }),
                attachmentValue: attachmentValue.response,
            };
            return Object.keys(attachmentValue).length !== 0 ? response : {};
        }
        // Falls der Anhang noch nicht ausgewählt wurde, wird an dem Frontend ein leeres Objekt zurückgeschickt
    } else return {};
});

export const handler = resolver.getDefinitions();
